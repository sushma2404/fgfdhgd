package banking.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import banking.bean.BankAccount;
import banking.dao.BankAccountDaoImpl;
import banking.exception.InsufficientBalanceException;
import banking.exception.InvalidAccountException;

public class BankAccountServiceImpl implements BankAccountService {
	static BankAccountDaoImpl dao = new BankAccountDaoImpl();
	static List<BankAccount> list = new ArrayList<BankAccount>();
	BankAccount bean=new BankAccount();
	
	@Override
	public double displayBalance(int accountNo) throws ClassNotFoundException, SQLException{

		// TODO Auto-generated method stub
		double balance=0;
		 try {
			bean = dao.displayBalance(accountNo);
			if (bean.getAccountNo()==0) {
				throw new InvalidAccountException("please enter valid accountNo");
			}
			else {
				balance= bean.getAccountBalance();
			}
		} 
		 catch (ClassNotFoundException | SQLException e) {
				System.out.println(e);
			}
		 catch (InvalidAccountException ex) {
				System.err.println(ex.getMessage());
		 }
		return balance;
	}

	@Override
	public void deposit(int accountNo, double amount)throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		double currBalance = 0;
		bean = dao.deposit(accountNo, amount);
		try {
			if (bean == null) {
				throw new InvalidAccountException("please enter valid accountNo");
			} else {
				dao.displayBalance(accountNo);
				double balance = bean.getAccountBalance();
				currBalance = balance + amount;
				bean.setAccountBalance(currBalance);
			}

		} catch (InvalidAccountException ex) {
			System.err.println(ex.getMessage());
		}
	}

	@Override
	public void withdraw(int accountNo, double amount)throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		double currBalance = 0;
		bean = dao.deposit(accountNo, amount);
		try {
			if (bean == null) {
				throw new InvalidAccountException("please enter valid accountNo");
			} else {
				dao.displayBalance(accountNo);
				double balance = bean.getAccountBalance();
				currBalance = balance - amount;
				try {
					if (currBalance < 0) {
						throw new InsufficientBalanceException("balance is less than the withdrawl amount");
					} else
						bean.setAccountBalance(currBalance);
				} catch (InsufficientBalanceException ex) {
					System.err.println(ex.getMessage());
				}
			}

		} catch (InvalidAccountException ex) {
			System.err.println(ex.getMessage());
		}

	}

	@Override
	public void fundTransfer(int accountNo1, int accountNo2, double amount)throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		double acc1Balance=0;
		double acc2Balance=0;
		int count=0;
		bean=dao.checkAccount(accountNo1);
		try {
			if (bean == null) {
				throw new InvalidAccountException("please enter valid accountNo");
			} else {
				dao.displayBalance(accountNo1);
				double balance = bean.getAccountBalance();
				acc1Balance = balance - amount;
				try {
					if (acc1Balance < 0) {
						count=1;
						throw new InsufficientBalanceException("balance is less than the withdrawl amount");
				    } 
					else
						bean.setAccountBalance(acc1Balance);
				} catch (InsufficientBalanceException ex) {
					System.err.println(ex.getMessage());
				}
			}

		} catch (InvalidAccountException ex) {
			System.err.println(ex.getMessage());
		}
		if(count==0)
		{
			bean=dao.checkAccount(accountNo1);
			try {
				if (bean == null) {
					throw new InvalidAccountException("please enter valid accountNo");
				} else {
					dao.displayBalance(accountNo1);
					double balance = bean.getAccountBalance();
					acc2Balance = balance - amount;
					try {
						if (acc2Balance < 0) {
							count=1;
							throw new InsufficientBalanceException("balance is less than the withdrawl amount");
					    } 
						else
							bean.setAccountBalance(acc2Balance);
					} catch (InsufficientBalanceException ex) {
						System.err.println(ex.getMessage());
					}
				}

			} catch (InvalidAccountException ex) {
				System.err.println(ex.getMessage());
			}
		}
	}

	@Override
	public void CreateAccount(int accountNo, String accountName, long accountBalance, long phoneNo, long initialBalance)
			throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		dao.CreateAccount(accountNo,accountName, accountBalance,phoneNo,initialBalance);
	}
}
	/*@Override
	public void printTransactions(int accountNo) {
		// TODO Auto-generated method stub
		Transaction trans = dao.printTransactions(accountNo);
		try {
			if (trans == null) {
				throw new InvalidAccountException("please enter valid accountNo");
			} else {
				System.out.println(trans);
			}

		} catch (InvalidAccountException ex) {
			System.err.println(ex.getMessage());
		}

	}
*/
	
