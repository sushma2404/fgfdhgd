package banking.bean;

public class BankAccount {
	private static int id = 100;
	private int accountNo;
	private String accountName;
	private double accountBalance;
	private long phoneNo;
	private double initialBalance;

	public BankAccount() {

	}

	public BankAccount(String accountName, long phoneNo, long accountBalance) {
		this.initialBalance = accountBalance;
		id++;
		this.accountNo = id;
		this.accountName = accountName;
		this.accountBalance = accountBalance;
		this.phoneNo = phoneNo;
	}

	public double getInitialBalance() {
		return initialBalance;
	}

	public void setInitialBalance(double initialBalance) {
		this.initialBalance = initialBalance;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double currBalance) {
		this.accountBalance = currBalance;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "BankAccount [accountNo=" + accountNo + ", accountName=" + accountName + ", accountBalance="
				+ accountBalance + ", phoneNo=" + phoneNo + ", initialBalance=" + initialBalance + "]";
	}

}
