package banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import banking.bean.BankAccount;
import banking.bean.Transaction;

public class BankAccountDaoImpl implements BankAccountDao {
	static List<BankAccount> list = new ArrayList<BankAccount>();
	static List<Transaction> transaction = new ArrayList<Transaction>();
	static BankAccount account = new BankAccount();
	 Connection conn;
	 PreparedStatement pstmt;
	 ResultSet rs;
	//int i = 0;
	 public void CreateAccount(int accountNo, String accountName, long accountBalance, long phoneNo,
				long initialBalance) throws SQLException, ClassNotFoundException {
			// TODO Auto-generated method stub
		 conn= DBUtil.getConnection();
		 String sql="insert into account values(?,?,?,?,?)";
	       pstmt=conn.prepareStatement(sql);
	       pstmt.setInt(1,accountNo );
	       pstmt.setString(2,accountName );
	       pstmt.setLong(3,accountBalance);
	       pstmt.setLong(4, phoneNo);
	       pstmt.setLong(5, initialBalance);
	       boolean exe =pstmt.execute();
		/*
		 * if(exe==true) { System.out.println("Data insertion failed"); } else
		 * System.out.println("Data inserted");
		 */

			
		}
	@Override
	public void CreateAccount(String accountName, long phoneNo, long accountBalance) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
       
		//list.add(bankaccount);
		//System.out.println("Account Created with accountId" + "  " + list.get(i).getAccountNo());
		// System.out.println("list data "+list);
		//i++;
       
	}

	@Override
	public BankAccount displayBalance(int accountNo) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		conn= DBUtil.getConnection();
        String sql="select * from account where accountNo=?";
        pstmt=conn.prepareStatement(sql);
        rs=pstmt.executeQuery();
        if(rs.next())
        {
        	account.setAccountNo(rs.getInt(1));
        	account.setAccountName(rs.getString(2));
        	account.setPhoneNo(rs.getLong(3));
        	account.setAccountBalance(rs.getDouble(4));
        }
        return account;
	}

		@Override
	public BankAccount deposit(int accountNo, double amount) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

			conn= DBUtil.getConnection();
	        String sql="select * from account where accountNo=?";
	        pstmt=conn.prepareStatement(sql);
	        rs=pstmt.executeQuery();
	        if(rs.next())
	        {
	        	account.setAccountNo(rs.getInt(1));
	        	account.setAccountName(rs.getString(2));
	        	account.setPhoneNo(rs.getLong(3));
	        	account.setAccountBalance(rs.getDouble(4));
	        }
	        return account;

	}

		@Override
	public BankAccount withdraw(int accountNo, double amount)throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
			conn= DBUtil.getConnection();
	        String sql="select * from account where accountNo=?";
	        pstmt=conn.prepareStatement(sql);
	        rs=pstmt.executeQuery();
	        if(rs.next())
	        {
	        	account.setAccountNo(rs.getInt(1));
	        	account.setAccountName(rs.getString(2));
	        	account.setPhoneNo(rs.getLong(3));
	        	account.setAccountBalance(rs.getDouble(4));
	        }
	        return account;
	}

		@Override
		public BankAccount checkAccount(int accountNo) throws ClassNotFoundException, SQLException {
			// TODO Auto-generated method stub
			conn= DBUtil.getConnection();
	        String sql="select * from account where accountNo=?";
	        pstmt=conn.prepareStatement(sql);
	        rs=pstmt.executeQuery();
	        if(rs.next())
	        {
	        	account.setAccountNo(rs.getInt(1));
	        	account.setAccountName(rs.getString(2));
	        	account.setPhoneNo(rs.getLong(3));
	        	account.setAccountBalance(rs.getDouble(4));
	        }
	        return account;
		}

		
}


		/*
		 * List<BankAccount> transfer = new ArrayList<BankAccount>(); for (int i = 0; i
		 * < list.size(); i++) { int accNo = list.get(i).getAccountNo(); if (accNo ==
		 * accountNo1 || accNo == accountNo2) { transfer.add(list.get(i)); } }
		 * 
		 * return transfer;
		 */


		/*@Override
	public Transaction printTransactions(int accountNo) {
		// TODO Auto-generated method stub
		conn= DBUtil.getConnection();
	        String sql="select * from account where accountNo=?";
	        pstmt=conn.prepareStatement(sql);
	        rs=pstmt.executeQuery();
	        if(rs.next())
	        {
	        	account.setAccountNo(rs.getInt(1));
	        	account.setAccountName(rs.getString(2));
	        	account.setPhoneNo(rs.getLong(3));
	        	account.setAccountBalance(rs.getDouble(4));
	        }
	        return account;
	}

	@Override
	public void update(int accountNo, BankAccount bankAccount) {
		// TODO Auto-generated method stub
		int j = 0;
		int count = 0;
		for (int i = 0; i < list.size(); i++) {
			int accNo = list.get(i).getAccountNo();
			if (accNo == accountNo) {
				list.set(i, bankAccount);
			}
		}

	}
*/
	

